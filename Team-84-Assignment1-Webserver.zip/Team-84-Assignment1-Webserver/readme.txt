For all functions used:



Structure of the project:
Firstly, we initialize the BBB, get the up-to-date libraries. We have three files app.js, index.html and package.json Our structure is building all function features on the app.js, and the web control interface is on index html which for user to communicate and control of the BBB hardware and software. Finally the package.json file is for user's reference to know what packages the project depends on.



For the packages used:
express - It listens to a socket to handle incoming requests.

socket.io - Socket.io aims to bring a WebSocket-like API to browsers and devicesIn this assignment, we use it to do some specific functions like sending data to control LED light ON or OFF, Motion Sensor On or Off and Receive and Display Data from Motion Sensor to help with user in real world realtime applications which we
have done on BBB.


Pins on BeagleBones Black have connected the LED and PIR:
LED:

PIR