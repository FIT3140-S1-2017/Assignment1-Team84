//Loading modules
var http = require('http');
console.log("http done")
var fs = require('fs');
console.log("fs done")
var path = require('path');
console.log("path done")
//var b = require('bonescript');
//console.log("bonescript done")
var io = require('socket.io')(http);
console.log("socket.io done")
var xx = 0;
var motions = 0;
var isMotion = 0
var longMotions = 0;
var shortMotions = 0;
var prevMotion = 0;
var currMotion = 0;
var motionType = 'Short';

// Create a variable called led, which refers to P9_14
var led = "P9_13";
// Initialize the led as an OUTPUT
//b.pinMode(led, 'out');

// Initialize the server on port 8888
var server = http.createServer(function (req, res) {
    // requesting files
    var file = '.' + ((req.url == '/') ? '/index.html' : req.url);
    var fileExtension = path.extname(file);
    var contentType = 'text/html';
    // Uncoment if you want to add css to your web page
    /*
    if(fileExtension == '.css'){
        contentType = 'text/css';
    }*/
    fs.exists(file, function (exists) {
        if (exists) {
            fs.readFile(file, function (error, content) {
                if (!error) {
                    // Page found, write content
                    res.writeHead(200, { 'content-type': contentType });
                    res.end(content);
                }
            })
        }
        else {
            // Page not found
            res.writeHead(404);
            res.end('Page not found');
        }
    })
}).listen(8888);

// Loading socket io module
io.listen(server);

// When communication is established
io.on('connection', function (socket) {
    socket.on('changeState', handleChangeState);
    socket.on('changePIRState', handlePIRstate);
});

// Change led state when a button is pressed
function handleChangeState(data) {
    var nLED = "P8_13";
    var b = require("bonescript")
    var newData = JSON.parse(data);
    console.log("LED = " + newData.state);
    console.log(nLED)
    // turns the LED ON or OFF
    b.digitalWrite(nLED, newData.state);
}

// Switch PIR sensor on or off
function handlePIRstate(pir_data) {
    motions = 0
	console.log('handlePIRState')
	var sensorData = JSON.parse(pir_data);
	if(sensorData.state == 0){
		stopPIR(xx);
	}
	else if(sensorData.state == 1){
		xx = setInterval(checkPIR, 2500); // Checks the Sensor Every 2.5 Seconds
	}
}

// Read data from sensor
function checkPIR(){
	console.log('checkPIR')
	var b = require('bonescript')
	b.pinMode('P8_9', b.INPUT);
	b.digitalRead('P8_9', printStatus);
	io.on('connection', function(socket){
	    socket.emit('serverCounter', motions);
	})
	console.log('server counts: '+motions);
}

// Increase motion counter
function motionCounter(){
    motions += 1;
}

// Stop PIR Sensor
function stopPIR(id) {
    clearInterval(id);
    console.log('stopped');
}

// Print PIR Sensor results
function printStatus(x) {
	var b = require('bonescript');
	var led = "P8_13";
	b.pinMode(led, 'out');
    if(x.value === 0){
         b.digitalWrite(led, 1);
         motionCounter();
         currMotion = 1;
         motionLength();
         prevMotion = 1;
    console.log("Motion Detected");
    }
    else{
    console.log("No Motion Detected");
         b.digitalWrite(led, 0);
         currMotion = 0;
         motionLength();
         prevMotion = 0;
    }
}

// Measure long motions (more than 2 consecutive motions)
function motionLength(){
    if (prevMotion == 0 && currMotion == 0 && motions == 0){
		console.log('First motion is no motion');
	}
	else if (prevMotion == 0 && currMotion == 1 && motions > 0){
		console.log('No new motion!');
	}
	else if (prevMotion == 0 && currMotion == 1 && motions > 0){
		motionType = 'Short';
	}
	// this if statement ensures that only when the long motion ends, its counted
	else if (prevMotion == 1 && currMotion == 0 && motions > 0){
		if (motionType == 'Short'){
			shortMotions += 1;
			console.log("shortMotions: "+shortMotions)
		}
		else if (motionType == 'Long'){
			longMotions += 1;
			console.log("longMotions: "+longMotions)
		}
	}
	else if (prevMotion == 1 && currMotion == 1 && motions > 0){
		motionType = 'Long';
	}
}
// Displaying a console message for user feedback
server.listen(console.log("Server Running ..."));