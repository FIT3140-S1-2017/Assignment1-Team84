var b = require('bonescript');
var led = "P8_13";
b.pinMode(led, 'out');
b.pinMode('P8_9', b.INPUT);
var i = 0;

var xx = setInterval(checkPIR, 2500); // Checks the Sensor Every 2.5 Seconds

function checkPIR(){
console.log("i_value: "+i)
if(i == 5){
    b.digitalRead('P8_9', printStatus);
    i += 1 
    } 
else{
    b.digitalRead('P8_9', printStatus);
    i += 1    
    }

}

function stopPIR(id) {
    clearInterval(id);
    console.log('stopped');
}

function printStatus(x) {
    if(x.value === 0){
         b.digitalWrite(led, 1);
    console.log("Motion Detected");
    }
    else{
    console.log("No Motion Detected");
         b.digitalWrite(led, 0);
    }
}
